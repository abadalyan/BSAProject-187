﻿
Namespace LightSwitchApplication

    Public Class New_Court_Case

        Private Sub New_Court_Case_InitializeDataWorkspace(ByVal saveChangesTo As Global.System.Collections.Generic.List(Of Global.Microsoft.LightSwitch.IDataService))
            ' Write your code here.
            Me.COURT_CASEProperty = New COURT_CASE()
        End Sub

        Private Sub New_Court_Case_Saved()
            ' Write your code here.
            Me.Close(False)
            Application.Current.ShowDefaultScreen(Me.COURT_CASEProperty)
        End Sub

    End Class

End Namespace