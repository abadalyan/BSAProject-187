﻿
Namespace LightSwitchApplication

    Public Class New_Data

    End Class

End Namespace
