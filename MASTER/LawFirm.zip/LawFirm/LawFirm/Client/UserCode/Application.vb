﻿
Namespace LightSwitchApplication

    Public Class Application

    End Class

End Namespace
